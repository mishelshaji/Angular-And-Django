from django.http import request
from django.http.response import HttpResponseBadRequest, HttpResponseNotFound, HttpResponseServerError
from django.shortcuts import render, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.core.serializers import json
from store.models import Movie

# Create your views here.
def view(request):
    if request.method != "GET":
        return HttpResponseBadRequest()

    movies = Movie.objects.all()
    serializer = json.Serializer()
    return HttpResponse(serializer.serialize(movies), content_type='application/json')

def view_single(request, id):
    if request.method != "GET":
        return HttpResponseBadRequest()

    movies = Movie.objects.filter(id=id)
    serializer = json.Serializer()
    return HttpResponse(serializer.serialize(movies), content_type='application/json')

@csrf_exempt
def create(request):
    print(request.method)
    if request.method != "POST":
        return HttpResponseBadRequest()
    
    try:
        m = Movie()
        m.name = request.POST.get("name")
        m.director = request.POST.get("director")
        m.description = request.POST.get("description")
        m.release_date = request.POST.get("release_date")
        m.save()
        return HttpResponse("OK")
    except Exception as e:
        print(e)
        return HttpResponseServerError()

def update(request, id):
    if request.method != "POST":
        return HttpResponseBadRequest()
    
    try:
        m = Movie.objects.get(pk=id)
        m.name = request.POST.get("name")
        m.director = request.POST.get("director")
        m.description = request.POST.get("description")
        m.release_date = request.POST.get("release_date")
        m.save()
        return HttpResponse("OK")
    except Exception as e:
        print(e)
        return HttpResponseNotFound()

def delete(request, id):
    if request.method != "GET":
        return HttpResponseBadRequest()
    
    try:
        movie = Movie.objects.get(pk=id)
        movie.delete()
    except Exception as e:
        print(e)
        return HttpResponseNotFound()